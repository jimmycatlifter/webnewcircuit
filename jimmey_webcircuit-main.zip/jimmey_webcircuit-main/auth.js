module.exports = {
  jwtSecret: 'your-very-secure-jwt-secret-key-nc',
  jwtExpiration: '24h',
  cookieName: 'auth_token'
};